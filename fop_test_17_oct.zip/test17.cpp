// #include<iostream>
// using namespace std;
// int main ()
// {
//         char choice;
//         double total = 0.0, value;
//     do 
//     {
//         // Display menu
//         cout << "\n--- Menu ---" << endl;
//         cout << "Enter A to add value" << endl;
//         cout << "Enter B to subtract value" << endl;
//         cout << "Enter D to display total" << endl;
//         cout << "Enter X to exit program" << endl;
//         cout << "Choose an option";
//         cin >> choice;
        
        
//         // Handle user input
//         switch (choice) 
//         {
//             case 'A' : case 'a' :
//                 cout << "Enter a value to add:";
//                 cin >> value;
//                 total += value;
//                 cout << "Value added." << endl;
//                 break;
                
//             case 'B' : case 'b' :
//                 cout << "Enter a value to subtract :";
//                 cin >> value;
//                 total += value;
//                 cout << "Value subtracted." << endl;
//                 break;
                
//             case 'D' : case 'd' :
//                 cout << "Current total is:" << total << endl; 
//                 break;
                
//             case 'X' :case 'x' :
//                 cout << "Exiting the program." << endl; 
//                 break;
                
//             defult:
//                 cout << "Invalid option. Please try again" << endl;
                
//         }
        
//     } while (choice != 'X' && choice != 'x');
    
//     return 0;
    
// }