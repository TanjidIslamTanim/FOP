// //sqcubewhile.cpp
// #include<iostream>
// using namespace std;
// int main()
// {
//     int num;
    
//     do
//     {
//         cout << "Enter an integer between 1 to 50"; 
//         cin >> num;
//         if (num >= 1 and num <= 50)
//             cout << "Yes, the no is between 1 to 50" <<endl;
//         else
//             cout << "Sorry invalid number" <<endl;
            
//     }while (num < 1 or num > 50);
// }//end of main

   