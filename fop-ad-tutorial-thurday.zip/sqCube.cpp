// //sqCube.cpp
// #include<iostream>
// using namespace std;

// int main()
// {
//     int num;
    
//     cout << "Number\t\tSquare\t\tCube\n";
    
//     for(num = 1; num <= 20; num++) 
//     {
//         cout << num << "\t\t" << num*num << "\t\t" << num*num*num << endl;
//     }// end of for loop
    
// }//end of loop