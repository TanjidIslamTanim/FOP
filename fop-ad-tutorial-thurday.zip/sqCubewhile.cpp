// //sqCubewhile.cpp
// #include<iostream>
// using namespace std;

// int main()
// {
//     int num;
    
//     cout << "Number\t\tSquare\t\tCube\n";
//     //initialiazation
//     num = 1;
    
//     //condition
//     while(num <= 20)
//     {
//         cout << num << "\t\t" << num*num << "\t\t" << num*num*num << endl;
//         //incrementation
//         num++;  //can use any method to increase
//     }
    
// }//end of main